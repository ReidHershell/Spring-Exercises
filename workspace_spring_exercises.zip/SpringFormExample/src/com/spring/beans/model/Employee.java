package com.spring.beans.model;

public class Employee 
{
	private int id;  
	private String firstname;  
	private String lastname;  
	private float salary;  
	private String designation;
	
	public Employee() 
	{
		
	}  
	public Employee(int id, String firstname, String lastname, float salary, String designation) 
	{  
	    super();  
	    this.id = id;  
	    this.firstname = firstname;  
	    this.lastname = lastname; 
	    this.salary = salary;  
	    this.designation = designation;  
	}  
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	
	public String getFirstname() 
	{
		return firstname;
	}
	public void setFirstname(String firstname) 
	{
		this.firstname = firstname;
	}
	public String getLastname() 
	{
		return lastname;
	}
	public void setLastname(String lastname) 
	{
		this.lastname = lastname;
	}
	
	public float getSalary() 
	{
		return salary;
	}
	public void setSalary(float salary) 
	{
		this.salary = salary;
	}
	public String getDesignation() 
	{
		return designation;
	}
	public void setDesignation(String designation) 
	{
		this.designation = designation;
	}

	
	

}
