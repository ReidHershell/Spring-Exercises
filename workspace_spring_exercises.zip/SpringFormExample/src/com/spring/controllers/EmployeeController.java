package com.spring.controllers;

import java.util.ArrayList;  
import java.util.List;  

import org.springframework.stereotype.Controller;  
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.servlet.ModelAndView;  

import com.spring.beans.model.Employee;
@Controller  
public class EmployeeController 
{  
	//write the code to get all employees from DAO  
    //here, we are writing manual code of list for easy understanding  
    List<Employee> list=new ArrayList<Employee>();
    int index = 0;
    
    @RequestMapping("/employeeform")  
    public ModelAndView showform()
    {  
         //command is a reserved request attribute name, now use <form> tag to show object data  
        return new ModelAndView("employeeform","command",new Employee());  
    }  
    
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("employee") Employee employee)
    {  	
    	employee.setId(list.size()+1);
    	list.add(employee);
        
    	//write code to save employee object  
        //here, we are displaying employee object to prove employee has data  
        System.out.println(employee.getFirstname()+" "+employee.getLastname()+" "+employee.getSalary()+" "+employee.getDesignation());  
          
        //return new ModelAndView("empform","command",employee);//will display object data  
        return new ModelAndView("redirect:/viewemployee");//will redirect to viewemployee request mapping  
    }  
    
  
    
    @RequestMapping("/viewemployee")  
    public ModelAndView viewemployee()
    {  
          
    	//example of employs saved
       // list.add(new Employee(1,"Aleph Adonai","Arra�aga Lozano",35000f,"S. Developer"));  
        //list.add(new Employee(2,"Leonardo","Acu�a Silva",25000f,"IT Manager"));  
        //list.add(new Employee(3,"Cristhian","Guzman Cristain",55000f,"IT Analyst"));  
          
        return new ModelAndView("viewemployee","list",list);  
    }  
}  